import React, { useState } from 'react';
import { ExternalLink, Github, Eye, Cpu, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { projects } from '../data/portfolioData';
import { Project } from '../types';
import { sfx } from '../utils/soundEffects';
import { useTheme } from '../context/ThemeContext';

export const ProjectsSection: React.FC = () => {
  const { theme } = useTheme();
  const isLight = theme === 'light';
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const handleOpenModal = (proj: Project) => {
    sfx.playClick();
    setSelectedProject(proj);
  };

  const handleCloseModal = () => {
    sfx.playClick();
    setSelectedProject(null);
  };

  return (
    <section id="projects" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-16">
          <div
            className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-mono mb-3 border transition-colors ${
              isLight
                ? 'bg-cyan-100 text-cyan-800 border-cyan-300'
                : 'bg-cyan-950/60 border-cyan-500/30 text-cyan-400'
            }`}
          >
            <span>&lt;MODULE_03: HARDWARE_&_CODE&gt;</span>
          </div>
          <h2
            className={`font-tech text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight uppercase transition-colors ${
              isLight ? 'text-slate-900' : 'text-white text-glow-cyan'
            }`}
          >
            PROJECTS I HAVE BUILT
          </h2>
          <div className="w-20 h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent my-3" />
          <p className={`font-mono text-xs sm:text-sm max-w-xl ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            Practical hardware prototypes, biomedical investigations, and embedded automation simulations.
          </p>
        </div>

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project) => (
            <div
              key={project.id}
              id={`project-card-${project.id}`}
              className={`rounded-2xl overflow-hidden border transition-all duration-300 flex flex-col group ${
                isLight
                  ? 'bg-white/95 border-slate-200/90 hover:border-cyan-400 hover:shadow-2xl shadow-md shadow-slate-200/60'
                  : 'bg-[#070e1f]/90 border-cyan-500/20 hover:border-cyan-400/60 hover:shadow-2xl hover:shadow-cyan-950/40'
              }`}
            >
              {/* Image Container */}
              <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />

                {/* Cyber Gradient Overlay */}
                <div
                  className={`absolute inset-0 bg-gradient-to-t ${
                    isLight
                      ? 'from-white/80 via-transparent to-black/20'
                      : 'from-[#070e1f] via-transparent to-black/40'
                  }`}
                />

                {/* Project Number HUD Tag */}
                <div
                  className={`absolute top-3 left-3 px-2.5 py-1 rounded-lg backdrop-blur-md font-mono text-xs font-bold border ${
                    isLight
                      ? 'bg-white/90 text-cyan-800 border-cyan-300 shadow-sm'
                      : 'bg-slate-950/80 text-cyan-300 border-cyan-500/40'
                  }`}
                >
                  {project.number}
                </div>

                {/* Category Badge */}
                <div
                  className={`absolute top-3 right-3 px-2.5 py-1 rounded-lg backdrop-blur-md font-mono text-xs border ${
                    isLight
                      ? 'bg-white/90 text-slate-700 border-slate-200 shadow-sm'
                      : 'bg-slate-950/80 text-slate-300 border-slate-700'
                  }`}
                >
                  {project.category}
                </div>

                {/* Prominent Tinkercad Simulation Banner for Project 03 */}
                {project.isSimulation && (
                  <div
                    id="tinkercad-banner"
                    className="absolute bottom-3 left-3 right-3 px-3 py-1.5 rounded-xl bg-amber-500/90 border border-amber-300 backdrop-blur-md text-amber-950 font-mono text-xs font-bold flex items-center justify-between shadow-lg"
                  >
                    <span className="flex items-center space-x-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-950" />
                      <span>Simulation Project — Tinkercad</span>
                    </span>
                    <span className="text-[10px] uppercase bg-amber-950 text-amber-200 px-1.5 py-0.5 rounded">
                      Verified Circuit
                    </span>
                  </div>
                )}
              </div>

              {/* Content Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3
                    className={`text-2xl font-tech font-bold transition-colors mb-2 ${
                      isLight ? 'text-slate-900 group-hover:text-cyan-700' : 'text-white group-hover:text-cyan-300'
                    }`}
                  >
                    {project.title}
                  </h3>

                  <p className={`text-sm font-sans leading-relaxed mb-5 ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
                    {project.description}
                  </p>

                  {/* Technologies */}
                  <div className="mb-6">
                    <div className="text-[11px] font-mono text-slate-400 uppercase mb-2">
                      Core Technologies:
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {project.technologies.map((tech, idx) => (
                        <span
                          key={idx}
                          className={`px-2.5 py-1 rounded-lg text-xs font-mono border transition-colors ${
                            isLight
                              ? 'bg-cyan-50 text-cyan-800 border-cyan-200'
                              : 'bg-cyan-950/40 text-cyan-200 border border-cyan-500/20'
                          }`}
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Actions Footer */}
                <div className={`pt-4 border-t flex items-center justify-between gap-2 ${isLight ? 'border-slate-100' : 'border-slate-800'}`}>
                  <button
                    onClick={() => handleOpenModal(project)}
                    onMouseEnter={() => sfx.playHover()}
                    className={`px-4 py-2 rounded-xl font-mono text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      isLight
                        ? 'bg-cyan-50 hover:bg-cyan-100 text-cyan-800 border border-cyan-300 shadow-sm'
                        : 'bg-cyan-950/80 hover:bg-cyan-900/80 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Details</span>
                  </button>

                  <div className="flex items-center space-x-2">
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="GitHub Repository (Placeholder)"
                      className={`p-2 rounded-xl border transition-colors ${
                        isLight
                          ? 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-200'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <Github className="w-4 h-4" />
                    </a>

                    <a
                      href={project.demoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="Live Demo / Simulation link (Placeholder)"
                      className={`p-2 rounded-xl border transition-colors ${
                        isLight
                          ? 'bg-slate-100 border-slate-200 text-slate-600 hover:text-cyan-700 hover:bg-cyan-50'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-cyan-400'
                      }`}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Project Detail Modal Window */}
      {selectedProject && (
        <div
          id="project-modal-backdrop"
          onClick={handleCloseModal}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-fade-in"
        >
          <div
            id="project-modal-container"
            onClick={(e) => e.stopPropagation()}
            className={`max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-2xl border p-6 shadow-2xl relative animate-scale-up ${
              isLight
                ? 'bg-white border-cyan-300 text-slate-900'
                : 'bg-[#0a1226] border-cyan-500/40 text-slate-100'
            }`}
          >
            {/* Modal Header */}
            <div className={`flex items-start justify-between pb-4 mb-4 border-b ${isLight ? 'border-slate-100' : 'border-cyan-500/20'}`}>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-cyan-100 text-cyan-800 border border-cyan-300 font-bold">
                    {selectedProject.number}
                  </span>
                  <span className="font-mono text-xs text-slate-400 uppercase">
                    {selectedProject.category}
                  </span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-tech font-bold mt-1">
                  {selectedProject.title}
                </h3>
              </div>

              <button
                onClick={handleCloseModal}
                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Simulation Platform Notice */}
            {selectedProject.isSimulation && (
              <div className="mb-4 p-3 rounded-xl bg-amber-100 border border-amber-300 text-amber-900 text-xs font-mono font-medium flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                <span>
                  <strong>Simulation Environment:</strong> Developed and verified using {selectedProject.simulationPlatform || 'Tinkercad Circuits'}.
                </span>
              </div>
            )}

            {/* Project Image Preview */}
            <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-950 mb-6 border border-slate-200">
              <img
                src={selectedProject.image}
                alt={selectedProject.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* In-depth description */}
            <div className={`space-y-4 mb-6 text-sm font-sans leading-relaxed ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
              <p>{selectedProject.longDescription || selectedProject.description}</p>
            </div>

            {/* Key Features */}
            {selectedProject.features && (
              <div className="mb-6">
                <h4 className="text-xs font-mono uppercase text-cyan-700 dark:text-cyan-400 tracking-wider mb-3 font-bold">
                  Technical Specifications & Architecture:
                </h4>
                <div className="space-y-2">
                  {selectedProject.features.map((feat, idx) => (
                    <div key={idx} className={`flex items-start space-x-2 text-xs sm:text-sm font-mono ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                      <CheckCircle2 className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Technology Stack */}
            <div className="mb-8">
              <h4 className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-2">
                Hardware / Components / Tools:
              </h4>
              <div className="flex flex-wrap gap-2">
                {selectedProject.technologies.map((t, i) => (
                  <span
                    key={i}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono border ${
                      isLight
                        ? 'bg-slate-100 text-slate-800 border-slate-200'
                        : 'bg-slate-900 text-cyan-300 border-cyan-500/30'
                    }`}
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>

            {/* Footer Buttons */}
            <div className={`pt-4 border-t flex flex-wrap items-center justify-between gap-3 ${isLight ? 'border-slate-100' : 'border-slate-800'}`}>
              <div className="flex items-center space-x-3">
                <a
                  href={selectedProject.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`px-4 py-2 rounded-xl font-mono text-xs font-medium flex items-center space-x-2 border transition-colors ${
                    isLight
                      ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800'
                      : 'bg-slate-900 hover:bg-slate-800 border-slate-700 text-slate-300'
                  }`}
                >
                  <Github className="w-4 h-4" />
                  <span>GitHub Repository</span>
                </a>
                <a
                  href={selectedProject.demoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`px-4 py-2 rounded-xl font-mono text-xs font-bold flex items-center space-x-2 border transition-colors ${
                    isLight
                      ? 'bg-cyan-50 hover:bg-cyan-100 border-cyan-300 text-cyan-800'
                      : 'bg-cyan-950 hover:bg-cyan-900 border-cyan-500/40 text-cyan-300'
                  }`}
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Demo / Schematic</span>
                </a>
              </div>

              <button
                onClick={handleCloseModal}
                className={`px-4 py-2 rounded-xl font-mono text-xs font-medium border ${
                  isLight
                    ? 'bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200'
                    : 'bg-slate-800 text-slate-300 hover:text-white border-slate-700'
                }`}
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
